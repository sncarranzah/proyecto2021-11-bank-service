package pe.com.bank.service.credit.repository;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import org.springframework.stereotype.Repository;
import pe.com.bank.service.credit.entity.CreditEntity;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface CreditRepository extends ReactiveMongoRepository<CreditEntity,String>
{
	Flux<CreditEntity> findByIdClientAndCreditTypeAndState(String idClient, String creditType, Byte state);
	
	Mono<CreditEntity> findByAccountNumber(String accountNumber);
}
