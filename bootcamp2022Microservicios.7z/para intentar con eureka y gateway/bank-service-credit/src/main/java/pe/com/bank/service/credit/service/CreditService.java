package pe.com.bank.service.credit.service;


import org.springframework.http.ResponseEntity;
import pe.com.bank.service.credit.entity.CreditEntity;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface CreditService {


	public ResponseEntity<Mono<CreditEntity>> save(CreditEntity CreditEntity);

	public Mono<CreditEntity> findById(String id);


	public Mono<CreditEntity> update(CreditEntity creditEntity);


	public Mono<Void> deleteById(String id);


	public Flux<CreditEntity> findAll();
	
	public Mono<CreditEntity> findByAccountNumber(String accountNumber);
}
