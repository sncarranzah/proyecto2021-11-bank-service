package pe.com.bank.service.credit.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import pe.com.bank.service.credit.dto.ClientEntity;
import pe.com.bank.service.credit.entity.CreditEntity;
import pe.com.bank.service.credit.repository.CreditRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class CreditServiceImpl implements CreditService {
	@Autowired
	private CreditRepository creditRepository;
	@Autowired
	private ClientServiceWeb clientServiceWeb;
	private Long countNormalActivesCreditsByPerson;

	@Override
	public ResponseEntity<Mono<CreditEntity>> save(CreditEntity creditEntity) {
		this.clientServiceWeb.findById(creditEntity.getIdClient());
		ClientEntity client = this.clientServiceWeb.getClientEntity();
		if (creditEntity.getCreditType().compareTo("NORMAL") == 0 && client.getClientType().compareTo("PERSON") == 0) {
			Flux<CreditEntity> normalActivesCreditsByPerson = this.creditRepository.findByIdClientAndCreditTypeAndState(
					creditEntity.getIdClient(), creditEntity.getCreditType(), (byte) 1);
			normalActivesCreditsByPerson.count()
			.subscribe(c -> this.countNormalActivesCreditsByPerson = c);
			if (this.countNormalActivesCreditsByPerson != 0) {
				System.out.println("El cliente persona ya tiene un prestamo activo.");//hacerlo con log
				return new ResponseEntity<>(Mono.just(new CreditEntity()), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		return ResponseEntity.ok(creditRepository.save(creditEntity));
	}

	@Override
	public Mono<CreditEntity> findById(String id) {
		return creditRepository.findById(id);
	}

	@Override
	public Mono<CreditEntity> update(CreditEntity creditEntity) {
		return creditRepository.save(creditEntity);
	}

	@Override
	public Mono<Void> deleteById(String id) {
		return creditRepository.deleteById(id);
	}

	@Override
	public Flux<CreditEntity> findAll() {
		return creditRepository.findAll();
	}
	
	public Mono<CreditEntity> findByAccountNumber(String accountNumber)
	{
		return this.creditRepository.findByAccountNumber(accountNumber);
	}

}
