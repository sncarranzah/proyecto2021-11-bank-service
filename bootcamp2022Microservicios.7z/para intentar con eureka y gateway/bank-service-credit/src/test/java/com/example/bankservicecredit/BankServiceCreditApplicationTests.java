package com.example.bankservicecredit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankServiceCreditApplicationTests {

	@Test
	void contextLoads() {
	}

}
