package pe.com.bank.service.movement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import lombok.extern.slf4j.Slf4j;
import pe.com.bank.service.movement.entity.MovementEntity;
import pe.com.bank.service.movement.service.MovementService;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
@RequestMapping("/api/movement")
public class MovementController 
{
	@Autowired
    private MovementService movementService;

    @PostMapping("/save")
    public Mono<MovementEntity> save(@RequestBody  MovementEntity movementEntity) {
        return this.movementService.save(movementEntity);
    }

    @GetMapping("/{id}")
    public Mono<MovementEntity> findById(@PathVariable String id) {
        return this.movementService.findById(id);
    }

    @PutMapping("/update")
    public Mono<MovementEntity> update(@RequestBody  MovementEntity movementEntity) {
        return this.movementService.update(movementEntity);
    }

    @DeleteMapping("/{id}")
    public Mono<Void> deleteById(@PathVariable String id) {
        return this.movementService.deleteById(id);
    }

    @GetMapping()
    public Flux<MovementEntity> findAll() {
        return this.movementService.findAll();
    }
    /*E.1.2 Un cliente deposita, retira o transfiere dinero desde su cuenta bancaria de debito*/
    @PostMapping("/depositWithdrawOrTransferMoneyFromBankAccount")
    public Mono<ResponseEntity<MovementEntity>> depositWithdrawOrTransferMoneyFromBankAccount(@RequestBody  MovementEntity movement) {
    	log.info("depositWithdrawOrTransferMoneyFromBankAccount executed {}", movement);
    	  return this.movementService.depositWithdrawOrTransferMoneyFromBankAccount(movement)
    			.map(monoMovementEnt->ResponseEntity.ok(monoMovementEnt))
                .defaultIfEmpty(ResponseEntity.notFound().build());
    			
    }
}
