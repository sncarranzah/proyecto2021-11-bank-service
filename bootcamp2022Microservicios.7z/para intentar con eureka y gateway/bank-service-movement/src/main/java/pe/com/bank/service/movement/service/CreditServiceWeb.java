package pe.com.bank.service.movement.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import lombok.Data;
import pe.com.bank.service.movement.dto.CreditEntity;
import reactor.core.publisher.Mono;

@Data
@Service
public class CreditServiceWeb {
	private final WebClient webClient;
	
	public CreditServiceWeb(@Value("${credit.service.url}") String url) {
        this.webClient = WebClient.builder().baseUrl(url).build();
    }
	
	public Mono<CreditEntity> findByAccountNumber(String accountNumber)
    {
    	return this.webClient.get()
                .uri("findByAccountNumber/" + accountNumber)
                .retrieve()
                .bodyToMono(CreditEntity.class); 
    }
	
}
