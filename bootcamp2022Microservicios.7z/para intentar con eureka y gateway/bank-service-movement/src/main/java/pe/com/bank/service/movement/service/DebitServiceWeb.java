package pe.com.bank.service.movement.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import lombok.Data;
import pe.com.bank.service.movement.dto.DebitEntity;
import pe.com.bank.service.movement.dto.DebitFeaturesEntity;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Data
@Service
public class DebitServiceWeb {
    private final WebClient webClient;


    public DebitServiceWeb(@Value("${debit.service.url}") String url) {
        this.webClient = WebClient.builder().baseUrl(url).build();
    }

    public Flux<DebitFeaturesEntity> findAllDebitFeatures() 
    {
		return this.webClient.get()
                .uri("findAllDebitFeatures")
                .retrieve()
                .bodyToFlux(DebitFeaturesEntity.class);              
    }
    
    public Mono<DebitEntity> findByAccountNumber(String accountNumber)
    {
    	return this.webClient.get()
                .uri("findByAccountNumber/" + accountNumber)
                .retrieve()
                .bodyToMono(DebitEntity.class); 
    }
    
    public Mono<DebitEntity> update(DebitEntity debit)
    {
    	return webClient.put()
    		.uri("update")
    		.body(Mono.just(debit), DebitEntity.class)
    		.retrieve()
    		.bodyToMono(DebitEntity.class);
    }
}
