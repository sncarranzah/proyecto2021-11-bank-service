package pe.com.bank.service.movement.service;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import pe.com.bank.service.movement.dto.CreditEntity;
import pe.com.bank.service.movement.dto.DebitEntity;
import pe.com.bank.service.movement.dto.DebitFeaturesEntity;
import pe.com.bank.service.movement.entity.MovementEntity;
import pe.com.bank.service.movement.repository.MovementRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class MovementServiceImpl implements  MovementService
{
	@Autowired
    private MovementRepository movementRepository;
	@Autowired
	private DebitServiceWeb debitServiceWeb;
	@Autowired
	private CreditServiceWeb creditServiceWeb;
	private CreditEntity credit;
	private DebitEntity debit;
	private ArrayList<DebitFeaturesEntity> debitFeaturesLst;
	

    @Override
    public Mono< MovementEntity> save( MovementEntity movementEntity) {
        return movementRepository.save(movementEntity);
    }

    @Override
    public Mono< MovementEntity> findById(String id) {
        return movementRepository.findById(id);
    }

    @Override
    public Mono< MovementEntity> update( MovementEntity movementEntity) {
        return movementRepository.save(movementEntity);
    }

    @Override
    public Mono<Void> deleteById(String id) {
        return movementRepository.deleteById(id);
    }

    @Override
    public Flux<MovementEntity> findAll() {
        return movementRepository.findAll();
    }
    
    /*E.1.2 Un cliente deposita, retira o transfiere dinero desde su cuenta bancaria de débito*/
    @Override
    public Mono<MovementEntity> depositWithdrawOrTransferMoneyFromBankAccount(MovementEntity movement)
    {
		log.trace("depositWithdrawOrTransferMoneyFromBankAccount executed {}", movement);
		return this.searchQuantityMovemInMonth(movement.getAccountNumber())
		.flatMap(quantMov -> this.getCommission(movement.getDebitType(), quantMov))
		.flatMap(commission ->
		{
			movement.setCommision((commission));
			return this.debitServiceWeb.findByAccountNumber(movement.getAccountNumber());
		})
		.flatMap(debit -> {
			log.trace("the origin debit is {}", debit);
			debit.setBalance(debit.getBalance() + movement.getAmount() - movement.getCommision());
			return Mono.just(debit);
		})
		.flatMap(debit ->
		{			
			if (debit.getBalance() >= 0)
			{
				log.trace("Punto de control 9 - Sammy");
				return this.debitServiceWeb.update(debit).flatMap(debitUpdated -> {
					log.trace("Punto de control 10 - Sammy: {}", debit);
					setMovementDate(movement);
					return this.save(movement).flatMap(movement2-> {
						if (movement.getDestinyAccountNumber()!= null)//si hay transferencia
						{
							MovementEntity destinityMovement = this.setDestinyMovement(movement);//se configura el movimiento del destino	
							return this.save(destinityMovement).flatMap(destinityMovementCreated -> {
								return this.debitServiceWeb.findByAccountNumber(movement.getDestinyAccountNumber())
								.flatMap(debitDestinity ->//tambien pudo haber sido map, daba igual
								{
									debitDestinity.setBalance(debitDestinity.getBalance() - movement.getAmount());
									return this.debitServiceWeb.update(debitDestinity).flatMap(debitUpdated2 -> Mono.just(movement2));
								});	
							});//se registra en la bd el movimiento del destino
						}
						return Mono.just(movement2);//new ResponseEntity<>(movementMono, HttpStatus.OK);
					}); 					
				});				
			}
			else
			{
				log.info("No tiene suficiente fondos para realizar la operacion.");
				return Mono.empty();//new ResponseEntity<>(new MovementEntity(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		});
		
    }

	private void setMovementDate(MovementEntity movement) {
		LocalDateTime dateTime = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		movement.setMovementDate(dateTime.format(formatter));
	}
    
    public MovementEntity setDestinyMovement(MovementEntity movement)
    {  	
    	MovementEntity destinityMovement = new MovementEntity();
    	
		destinityMovement.setAmount(-movement.getAmount());
		destinityMovement.setOriginAccountNumber(movement.getOriginAccountNumber());
		destinityMovement.setDestinyAccountNumber(movement.getDestinyAccountNumber());
		destinityMovement.setAccountNumber(movement.getDestinyAccountNumber());
		this.debitServiceWeb.findByAccountNumber(movement.getDestinyAccountNumber())
		.subscribe(d -> this.debit = d);
		if (this.debit != null)//en caso sea debito
		{
			destinityMovement.setAccountType("DEBIT");
			destinityMovement.setDebitType(this.debit.getDebitType());
		}
		else // en caso sea credito
		{
			this.creditServiceWeb.findByAccountNumber(movement.getDestinyAccountNumber())
			.subscribe(c -> this.credit = c);
			destinityMovement.setAccountType("CREDIT");
			destinityMovement.setCreditType(this.credit.getCreditType());
		}
		destinityMovement.setCommision(0.0);
		destinityMovement.setConcept("TRANSFERENCIA");

		setMovementDate(destinityMovement);
		return destinityMovement;
    }
    
    public Mono<Long> searchQuantityMovemInMonth(String accountNumber)
    {
    	log.trace("searchQuantityMovemInMonth executed {}", accountNumber);
    	Calendar cal = Calendar.getInstance();
    	int actualYear = cal.get(Calendar.YEAR);
    	int actualMonth = cal.get(Calendar.MONTH);
    	int lastDayMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
    	String startdate = actualYear + "-" + actualMonth + "-" + "1" + "'T'" + "00:00:00.000'Z'";
    	String endDate = actualYear + "-" + actualMonth + "-" + lastDayMonth + "'T'" + "23:59:59.999'Z'";
    	Flux<MovementEntity> fluxMov = this.movementRepository.findByMovementDateBetweenAndAccountNumber(startdate,endDate,accountNumber);
    	log.trace("The quantity movement in month is: {}", fluxMov.count());
    	return fluxMov.count();
    }
    
    
    public Mono<Double> getCommission(String debitType,Long movemInMonth)
    {
    	log.trace("getCommission executed {} : {}", debitType,movemInMonth);
    	return this.debitServiceWeb.findAllDebitFeatures().
    	map(debitFeaturesBD -> 
    		{
    			Double commission;
    	    	if (debitType == "SAVINGS" && movemInMonth > debitFeaturesBD.getMaxNumberMovemSavingsByMonth()) commission = debitFeaturesBD.getCommisAmountByMovemSaving();
    	    	else if (debitType == "CURRENT ACCOUNT" && movemInMonth > debitFeaturesBD.getMaxNumberMovemCurrentAccountByMonth()) commission = debitFeaturesBD.getCommisAmountByMovemCurrentAccount();
    	    	else if (debitType == "FIXED TERM" && movemInMonth > debitFeaturesBD.getMaxNumberMovemFixedTermByMonth()) commission = debitFeaturesBD.getCommisAmountByMovemFixedTerm();
    	    	else commission = 0.0;
    	    	return commission;
    		}
    	).elementAt(0);
    }
}
