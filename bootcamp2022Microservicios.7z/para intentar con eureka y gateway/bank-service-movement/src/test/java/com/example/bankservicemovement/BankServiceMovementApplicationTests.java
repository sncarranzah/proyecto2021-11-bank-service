package com.example.bankservicemovement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankServiceMovementApplicationTests {

	@Test
	void contextLoads() {
	}

}
