package com.example.bankserviceclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankServiceClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
