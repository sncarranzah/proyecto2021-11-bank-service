package pe.com.bank.service.client.service;

import pe.com.bank.service.client.entity.ClientEntity;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface ClientService {
	Mono<ClientEntity> save(ClientEntity cardEntity);

    Mono<ClientEntity> findById(String id);

    Mono<ClientEntity> update(ClientEntity cardEntity);

    Mono<Void> deleteById(String id);

    Flux<ClientEntity> findAll();
}
