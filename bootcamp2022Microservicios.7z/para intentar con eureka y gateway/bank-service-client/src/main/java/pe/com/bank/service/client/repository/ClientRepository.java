package pe.com.bank.service.client.repository;


import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Repository;
import pe.com.bank.service.client.entity.ClientEntity;

@Repository
public interface ClientRepository extends ReactiveMongoRepository<ClientEntity,String>{

}
