package pe.com.bank.service.debit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import lombok.extern.slf4j.Slf4j;
import pe.com.bank.service.debit.entity.DebitEntity;
import pe.com.bank.service.debit.entity.DebitFeaturesEntity;
import pe.com.bank.service.debit.service.DebitService;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
@RequestMapping("/api/debit")
public class DebitController {
    @Autowired
    private DebitService debitService;
    
    /*E1.1 Un cliente (personal o empresarial ) solicita una cuenta bancaria de debito.*/
    @PostMapping("/save")
    public ResponseEntity<DebitEntity> saveDebit(@RequestBody DebitEntity debitEntity) {
    	log.info("saveDebit executed {}", debitEntity);
        return this.debitService.save(debitEntity);
    }

    @GetMapping("/{id}")
    public Mono<DebitEntity> findById(@PathVariable String id) {
        return this.debitService.findById(id);
    }

    @PutMapping("/update")
    public Mono<DebitEntity> updateDebit(@RequestBody DebitEntity debitEntity) {
    	log.info("updateDebit executed {}", debitEntity);
        return this.debitService.update(debitEntity);
    }

    @DeleteMapping("/{id}")
    public Mono<Void> deleteIdDebit(@PathVariable String id) {
        return this.debitService.deleteById(id);
    }

    @GetMapping()
    public Flux<DebitEntity> findAllDebit() {
        return this.debitService.findAll();
    }
    
    @GetMapping("/findAllDebitFeatures")
    public Flux<DebitFeaturesEntity> findAllDebitFeatures() {
        return this.debitService.findAllDebitFeatures();
    }
    
    @GetMapping("findByAccountNumber/{accountNumber}")
    public Mono<DebitEntity> findByAccountNumber(@PathVariable String accountNumber) {
        return this.debitService.findByAccountNumber(accountNumber);
    }
}
