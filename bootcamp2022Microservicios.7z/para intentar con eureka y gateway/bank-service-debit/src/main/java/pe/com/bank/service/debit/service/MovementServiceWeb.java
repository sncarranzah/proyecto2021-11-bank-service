package pe.com.bank.service.debit.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import lombok.Data;
import pe.com.bank.service.debit.dto.MovementEntity;
import reactor.core.publisher.Mono;

@Data
@Service
public class MovementServiceWeb {
	
	private final WebClient webClient;


    public MovementServiceWeb(@Value("${movement.service.url}") String url) {
        this.webClient = WebClient.builder().baseUrl(url).build();
    }
    
    public Mono<MovementEntity> save(MovementEntity movement)
    {
    	return webClient.post()
    		.uri("save")
    		.body(Mono.just(movement), MovementEntity.class)
    		.retrieve()
    		.bodyToMono(MovementEntity.class);
    }

}
