package pe.com.bank.service.debit.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Document(collection="movement")
public class MovementEntity 
{
	@Id
	private String id;
	private String movementDate;
	private Double amount;
	private String accountNumber;
	private String originAccountNumber;
	private String destinyAccountNumber;
	private String accountType; // "DEBIT" O "CREDIT"
	private Double commision;
	private String concept;
	private String debitType;
	private String creditType;
	private String cardNumber;
}
