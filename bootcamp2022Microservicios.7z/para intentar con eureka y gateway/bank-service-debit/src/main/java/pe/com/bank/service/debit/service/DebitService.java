package pe.com.bank.service.debit.service;

import org.springframework.http.ResponseEntity;

import pe.com.bank.service.debit.entity.DebitEntity;
import pe.com.bank.service.debit.entity.DebitFeaturesEntity;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface DebitService {
	ResponseEntity<DebitEntity> save(DebitEntity debitEntity);

    Mono<DebitEntity> findById(String id);

    Mono<DebitEntity> update(DebitEntity debitEntity);

    Mono<Void> deleteById(String id);

    Flux<DebitEntity> findAll();
    
    Flux<DebitFeaturesEntity> findAllDebitFeatures();
    
    Mono<DebitEntity> findByAccountNumber(String accountNumber);
}
