package pe.com.bank.service.debit.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Document(collection="debit_features")
public class DebitFeaturesEntity {
	@Id
	private String id;
	private Long maxNumberMovemSavingsByMonth;
	private Long maxNumberMovemCurrentAccountByMonth;
	private Long maxNumberMovemFixedTermByMonth;
	private Double commisAmountByMovemSaving;
	private Double commisAmountByMovemCurrentAccount;
	private Double commisAmountByMovemFixedTerm;
	
}
