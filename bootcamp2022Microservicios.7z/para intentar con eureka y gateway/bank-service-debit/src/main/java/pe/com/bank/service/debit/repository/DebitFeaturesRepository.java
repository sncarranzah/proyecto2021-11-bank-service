package pe.com.bank.service.debit.repository;


import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import pe.com.bank.service.debit.entity.DebitFeaturesEntity;

public interface DebitFeaturesRepository extends ReactiveMongoRepository<DebitFeaturesEntity, String> {

}
