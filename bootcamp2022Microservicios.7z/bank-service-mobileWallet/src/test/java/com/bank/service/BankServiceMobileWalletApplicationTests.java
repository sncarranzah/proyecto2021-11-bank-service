package com.bank.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankServiceMobileWalletApplicationTests {

	@Test
	void contextLoads() {
	}

}
