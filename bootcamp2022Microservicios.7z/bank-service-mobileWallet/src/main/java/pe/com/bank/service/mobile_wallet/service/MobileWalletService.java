package pe.com.bank.service.mobile_wallet.service;

import pe.com.bank.service.mobile_wallet.entity.MobileWalletEntity;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface MobileWalletService {
	Mono<MobileWalletEntity> save(MobileWalletEntity mobileWalletEntity);
	Mono<MobileWalletEntity> update(MobileWalletEntity mobileWalletEntity);

}
