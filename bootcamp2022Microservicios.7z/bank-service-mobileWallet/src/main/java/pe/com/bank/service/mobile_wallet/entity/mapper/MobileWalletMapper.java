package pe.com.bank.service.mobile_wallet.entity.mapper;

import org.mapstruct.Mapper;

import pe.com.bank.service.mobile_wallet.entity.MobileWalletEntity;
import pe.com.bank.service.mobile_wallet.entity.model.MobileWalletModel;

@Mapper(componentModel = "spring")
public interface MobileWalletMapper {
	MobileWalletEntity modelToEntity(MobileWalletModel model);
	MobileWalletModel entityToModel(MobileWalletEntity event);
}
