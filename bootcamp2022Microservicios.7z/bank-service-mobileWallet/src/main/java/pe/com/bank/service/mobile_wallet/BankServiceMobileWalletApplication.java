package pe.com.bank.service.mobile_wallet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankServiceMobileWalletApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankServiceMobileWalletApplication.class, args);
	}

}
