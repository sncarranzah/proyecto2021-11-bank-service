package pe.com.bank.service.mobile_wallet.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import pe.com.bank.service.mobile_wallet.entity.MobileWalletEntity;
import pe.com.bank.service.mobile_wallet.repository.MobileWalletRepository;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class MobileWalletServiceImpl implements  MobileWalletService
{
	@Autowired
    private MobileWalletRepository mobileWalletRepository;

    @Override
    public Mono<MobileWalletEntity> save( MobileWalletEntity mobileWalletEntity) {
    	log.trace("save executed {}", mobileWalletEntity);
        return this.mobileWalletRepository.save(mobileWalletEntity);
    }

    @Override
    public Mono<MobileWalletEntity> update( MobileWalletEntity mobileWalletEntity) {
    	log.trace("update executed {}", mobileWalletEntity);
        return this.mobileWalletRepository.save(mobileWalletEntity);
    }

}
