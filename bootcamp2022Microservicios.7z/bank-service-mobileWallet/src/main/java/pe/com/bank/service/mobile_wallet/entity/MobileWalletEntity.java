package pe.com.bank.service.mobile_wallet.entity;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@Document(collection="mobileWalletEntity")
public class MobileWalletEntity 
{
	@Id
	private String id;
	private Long foreignerCard;
	private Long dni;
	private Long cellphoneNumber;
	private Double balance;
	private String associatedCardNumber_card; 
}
