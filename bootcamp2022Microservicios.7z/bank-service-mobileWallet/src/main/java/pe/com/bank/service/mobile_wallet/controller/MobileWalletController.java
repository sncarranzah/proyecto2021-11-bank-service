package pe.com.bank.service.mobile_wallet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import lombok.extern.slf4j.Slf4j;
import pe.com.bank.service.mobile_wallet.entity.mapper.MobileWalletMapper;
import pe.com.bank.service.mobile_wallet.entity.model.MobileWalletModel;
import pe.com.bank.service.mobile_wallet.service.MobileWalletService;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
@RequestMapping("/api/mobile_wallet")
public class MobileWalletController 
{
	@Autowired
    private MobileWalletService mobileWalletService;
	
	@Autowired
	private MobileWalletMapper mobilWalletMapper;
 
    /*E4.1 Una persona solicita un monedero movil.*/
    @PostMapping()
    public Mono<ResponseEntity<MobileWalletModel>> save(@RequestBody  MobileWalletModel mobileWalletModel) {
    	log.info("save executed {}", mobileWalletModel);
    	return this.mobileWalletService.save(this.mobilWalletMapper.modelToEntity(mobileWalletModel))
		.map(mobileWalletEntity->
		{
			log.info("punto de control - Sammy: mobile_walletEntity: {}", mobileWalletEntity);
			MobileWalletModel mobileWalletModel2 = this.mobilWalletMapper.entityToModel(mobileWalletEntity);
			
			return ResponseEntity.ok(mobileWalletModel2);
		})
        .defaultIfEmpty(ResponseEntity.notFound().build());
    			
    }
    
    /*E4.3 Un persona asocia su monedero movil a la cuenta de debito principal de una tarjeta de debito*/
    @PutMapping()
	public Mono<ResponseEntity<MobileWalletModel>> update(@RequestBody MobileWalletModel mobileWalletModel) {
    	return this.mobileWalletService.update(this.mobilWalletMapper.modelToEntity(mobileWalletModel))
		.map(mobileWalletEntity->
		{
			log.info("punto de control - Sammy: mobile_walletEntity: {}", mobileWalletEntity);
			MobileWalletModel mobileWalletModel2 = this.mobilWalletMapper.entityToModel(mobileWalletEntity);
			
			return ResponseEntity.ok(mobileWalletModel2);
		})
		.defaultIfEmpty(ResponseEntity.notFound().build());
	}
}
