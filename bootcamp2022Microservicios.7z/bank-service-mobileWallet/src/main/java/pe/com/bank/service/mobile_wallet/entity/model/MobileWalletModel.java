package pe.com.bank.service.mobile_wallet.entity.model;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.com.bank.service.mobile_wallet.entity.MobileWalletEntity;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class MobileWalletModel {
	@Id
	private String id;
	private Long foreignerCard;
	private Long dni;
	private Long cellphoneNumber;
	private Double balance;
	private String associatedCardNumber_card; 
}
