package pe.com.bank.service.card;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankServiceCardApplicationTests {

	@Test
	void contextLoads() {
	}

}
