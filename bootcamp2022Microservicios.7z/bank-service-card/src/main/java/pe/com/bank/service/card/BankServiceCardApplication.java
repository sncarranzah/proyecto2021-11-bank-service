package pe.com.bank.service.card;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankServiceCardApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankServiceCardApplication.class, args);
	}

}
