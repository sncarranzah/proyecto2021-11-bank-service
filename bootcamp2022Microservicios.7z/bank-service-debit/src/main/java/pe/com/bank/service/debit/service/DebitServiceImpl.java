package pe.com.bank.service.debit.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import lombok.extern.slf4j.Slf4j;
import pe.com.bank.service.debit.dto.MovementEntity;
import pe.com.bank.service.debit.entity.DebitEntity;
import pe.com.bank.service.debit.entity.DebitFeaturesEntity;
import pe.com.bank.service.debit.repository.DebitFeaturesRepository;
import pe.com.bank.service.debit.repository.DebitRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class DebitServiceImpl implements DebitService {
	
    @Autowired
    private DebitRepository debitRepository;
    @Autowired
    private DebitFeaturesRepository debitFeaturesRepository;
    @Autowired
    private ClientServiceWeb clientServiceWeb;
    private Long countDebitEntitiesPerson;
    @Autowired
    private MovementServiceWeb movementServiceWeb;
    private DebitEntity debitPersonResponse;
    private DebitEntity debitEnterpriseResponse;
    private DebitEntity debit;
    
    /*E1.1  Un cliente (personal o empresarial ) solicita una cuenta bancaria de débito.*/
	/*Registra una cuenta de debito para una persona o para una empresa.
	Condiciones: Una persona solo puede tener como maximo una cuenta de debito de cada tipo (savings, current account, fixed
	term), y una empresa solo puede tener multiples cuentas en current account pero no en otros tipos de cuentas de debito..*/
    @Override
    public ResponseEntity<DebitEntity> save(DebitEntity debitEntity) {
    	this.debitRepository.findByAccountNumber(debitEntity.getAccountNumber()).subscribe(d -> this.debit = d);
    	if (this.debit == null)
    	{
    		log.trace("Sammy punto 1: {}",debitEntity.getIdClient());
	    	this.clientServiceWeb.findById(debitEntity.getIdClient());
	    	String clientType = this.clientServiceWeb.getClientEntity().getClientType();
	    	if (clientType.compareTo("PERSON") == 0)
	    	{
	    		Flux<DebitEntity> debitEntitiesPerson = this.debitRepository.findByIdClientAndDebitType(debitEntity.getIdClient(), debitEntity.getDebitType());
	    		//count() es un operador terminal
	    		debitEntitiesPerson.count()
				.subscribe(c -> this.countDebitEntitiesPerson = c);
	    		if (this.countDebitEntitiesPerson == 0) 
	    		{
	
	    			this.debitRepository.save(debitEntity).subscribe(d -> this.debitPersonResponse = d);
	    			MovementEntity movementEntity = new MovementEntity();
	    			this.configureMovement(debitEntity, movementEntity);
	    			log.trace("Sammy punto 2: {}", movementEntity);
	    			this.movementServiceWeb.save(movementEntity).subscribe();//.subscribe(m -> this.movementEntity = m);
	    			log.info("Se registro la nueva cuenta de debito de la persona exitosamente");
	    			return new ResponseEntity<>(this.debitPersonResponse ,HttpStatus.OK);
	    		}
	    		else
	    		{
	    			log.info("El cliente ya posee una cuenta de debito de tipo: {}; no puede tener más de 1", debitEntity.getDebitType());
	    			return new ResponseEntity<>(new DebitEntity() , HttpStatus.INTERNAL_SERVER_ERROR);
	    		}
	    			
	    	}
	    	else if (clientType.compareTo("ENTERPRISE") == 0)
	    	{
	    		String debitType = debitEntity.getDebitType();
	    		if (debitType.compareTo("SAVINGS") == 0 || debitType.compareTo("FIXED TERM") == 0 )
	    		{
	    			log.info("La empresa no se le esta permitida tener una cuenta de ahorrro o una cuenta fija");
	    			return new ResponseEntity<>(new DebitEntity() , HttpStatus.INTERNAL_SERVER_ERROR);
	    		}	
	    		else if (debitType.compareTo("CURRENT ACCOUNT") == 0)
	    		{
	    			this.debitRepository.save(debitEntity).subscribe(d -> this.debitEnterpriseResponse = d);
	    			MovementEntity movementEntity = new MovementEntity();
	    			this.configureMovement(debitEntity, movementEntity);
	    			this.movementServiceWeb.save(movementEntity).subscribe();
	    			log.info("Se registro la nueva cuenta de debito de la empresa exitosamente");
	    			return new ResponseEntity<>(this.debitEnterpriseResponse, HttpStatus.OK);
	    		}
	    		else
	    		{
	    			log.warn("Error en los datos de entrada: DebitEntity");
	    			return new ResponseEntity<>(new DebitEntity() , HttpStatus.INTERNAL_SERVER_ERROR);
	    		}
	    	}
	    	else
			{
	    		log.warn("Error en los datos: clientType");
				return new ResponseEntity<>(new DebitEntity() , HttpStatus.INTERNAL_SERVER_ERROR);
			}
    	}
    	else
    	{
    		log.warn("Ya existe una cuenta de debito con ese numero de cuenta");
    		return new ResponseEntity<>(new DebitEntity() , HttpStatus.INTERNAL_SERVER_ERROR);
    	}
    	
    }

    @Override
    public Mono<DebitEntity> findById(String id) {
        return debitRepository.findById(id);
    }

    @Override
    public Mono<DebitEntity> update(DebitEntity debitEntity) {
    	log.trace("update executed {}", debitEntity);
        return debitRepository.save(debitEntity);
    }

    @Override
    public Mono<Void> deleteById(String id) {
    	
        return debitRepository.deleteById(id);
    }

    @Override
    public Flux<DebitEntity> findAll() {
        return debitRepository.findAll();
    }
    
    @Override
    public Flux<DebitFeaturesEntity> findAllDebitFeatures() {
        return debitFeaturesRepository.findAll();
    }
    
    public Mono<DebitEntity> findByAccountNumber(String accountNumber)
    {
    	return this.debitRepository.findByAccountNumber(accountNumber);
    }
    
    public void configureMovement(DebitEntity debit, MovementEntity movement)
    {
    	LocalDateTime dateTime = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		movement.setMovementDate(dateTime.format(formatter));
		movement.setAmount(debit.getBalance());
		movement.setAccountNumber(debit.getAccountNumber());
		movement.setAccountType("DEBIT");
		movement.setConcept("ACCOUNT OPENING");
		movement.setDebitType(debit.getDebitType());		
    }

}
