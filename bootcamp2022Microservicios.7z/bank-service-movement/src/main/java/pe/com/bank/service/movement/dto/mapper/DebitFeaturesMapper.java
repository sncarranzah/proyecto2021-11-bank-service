package pe.com.bank.service.movement.dto.mapper;

import org.mapstruct.Mapper;

import pe.com.bank.service.movement.dto.DebitFeaturesEntity;
import pe.com.bank.service.movement.dto.model.DebitFeaturesModel;

@Mapper(componentModel = "spring")
public interface DebitFeaturesMapper {
	DebitFeaturesEntity modelToEntity(DebitFeaturesModel model);
	DebitFeaturesModel entityToModel(DebitFeaturesEntity event);
}
