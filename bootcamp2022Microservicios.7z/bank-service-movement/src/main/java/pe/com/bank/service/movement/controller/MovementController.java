package pe.com.bank.service.movement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import lombok.extern.slf4j.Slf4j;
import pe.com.bank.service.movement.entity.MovementEntity;
import pe.com.bank.service.movement.entity.mapper.MovementMapper;
import pe.com.bank.service.movement.entity.model.MovementModel;
import pe.com.bank.service.movement.service.MovementService;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@RestController
@RequestMapping("/api/movement")
public class MovementController 
{
	@Autowired
    private MovementService movementService;
	
	@Autowired
	private MovementMapper movementMapper;

	/*No puede haber un metodo save porque es muy general para este caso: cada movimiento de debito y de credito se van a manejar
	 por metodos por separado.*/
	
    @GetMapping("/{id}")
    public Mono<MovementEntity> findById(@PathVariable String id) {
        return this.movementService.findById(id);
    }

    @PutMapping("/update")
	public Mono<ResponseEntity<MovementModel>> update(@RequestBody MovementModel movementModel) {
		return this.movementService.update(this.movementMapper.modelToEntity(movementModel))
		.map(movementEntity -> 
		{
			log.info("punto de control 1 - Sammy: movementEntity: {}", movementEntity);
			MovementModel movementModel2 = this.movementMapper.entityToModel(movementEntity);
			return ResponseEntity.ok(movementModel2);
		})
		.defaultIfEmpty(ResponseEntity.notFound().build());
	}

    @DeleteMapping("/{id}")
    public Mono<ResponseEntity<Void>> deleteById(@PathVariable String id) {
    	log.info("deleteById executed {}", id);
        return this.movementService.deleteById(id)
        .map(r -> ResponseEntity.ok().<Void>build())
        .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @GetMapping()
    public Mono<ResponseEntity<Flux<MovementModel>>> findAll() {
        log.info("findAll executed");
        return Mono.just(ResponseEntity.ok()
        		.body(this.movementService.findAll()
        		.map(movementEntity -> this.movementMapper.entityToModel(movementEntity))));
    }
    
    
    /*E.1.2 Un cliente realiza un movimiento (deposita, retira o transfiere dinero) desde su cuenta bancaria de debito*/
    @PostMapping("/depositWithdrawOrTransferMoneyFromBankAccount")
    public Mono<ResponseEntity<MovementModel>> depositWithdrawOrTransferMoneyFromBankAccount(@RequestBody  MovementModel movementModel) {
    	log.info("depositWithdrawOrTransferMoneyFromBankAccount executed {}", movementModel);
    	return this.movementService.depositWithdrawOrTransferMoneyFromBankAccount(this.movementMapper.modelToEntity(movementModel))
		.map(movementEntity->
		{
			log.info("punto de control 2 - Sammy: movementEntity: {}", movementEntity);
			MovementModel movementModel2 = this.movementMapper.entityToModel(movementEntity);
			return ResponseEntity.ok(movementModel2);
		})
        .defaultIfEmpty(ResponseEntity.notFound().build());
    			
    }
    


}
