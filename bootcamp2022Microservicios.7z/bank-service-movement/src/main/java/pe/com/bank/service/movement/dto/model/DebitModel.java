package pe.com.bank.service.movement.dto.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class DebitModel
{
	@Id
	private String id;
	private Double balance;
	private String idClient;
	@Indexed(unique=true)
	private String accountNumber;
	private String cardNumber;
	private Integer cardAssociationOrder;
	private String debitType; //"SAVINGS", "CURRENT ACCOUNT","FIXED TERM"
}
