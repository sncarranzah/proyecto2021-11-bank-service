package pe.com.bank.service.movement.entity.mapper;

import org.mapstruct.Mapper;

import pe.com.bank.service.movement.entity.MovementEntity;
import pe.com.bank.service.movement.entity.model.MovementModel;

@Mapper(componentModel = "spring")
public interface MovementMapper {
	MovementEntity modelToEntity(MovementModel model);
	MovementModel entityToModel(MovementEntity event);
}
