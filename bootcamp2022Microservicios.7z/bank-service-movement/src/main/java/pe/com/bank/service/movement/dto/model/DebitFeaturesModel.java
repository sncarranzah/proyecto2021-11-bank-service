package pe.com.bank.service.movement.dto.model;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class DebitFeaturesModel {
	@Id
	private String id;
	private Long maxNumberMovemSavingsByMonth;
	private Long maxNumberMovemCurrentAccountByMonth;
	private Long maxNumberMovemFixedTermByMonth;
	private Double commisAmountByMovemSaving;
	private Double commisAmountByMovemCurrentAccount;
	private Double commisAmountByMovemFixedTerm;
	
}
