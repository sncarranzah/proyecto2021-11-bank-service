package pe.com.bank.service.movement.entity.model;

import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class MovementModel {
	@Id
	private String id;
	private String movementDate;
	private Double amount;
	private String accountNumber;
	private String originAccountNumber;
	private String destinyAccountNumber;
	private String accountType; // "DEBIT, CREDIT"
	private Double commision;
	private String concept; //"ACCOUNT OPENING, DEPOSIT, WITHDRAWAL, CREDIT CONSUMPTION , CREDIT PAYMENT"
	private String debitType;
	private String creditType;
	private String cardNumber;
	private String associatedCardNumber;//numero de tarjeta de debito asociada
	private Long cellphoneNumber;
}
