package pe.com.bank.service.movement.service;

import pe.com.bank.service.movement.entity.MovementEntity;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface MovementService {
	Mono<MovementEntity> save(MovementEntity movementEntity);
    Mono<MovementEntity> findById(String id);

    Mono<MovementEntity> update(MovementEntity movementEntity);

    Mono<Void> deleteById(String id);

    Flux<MovementEntity> findAll();
    
    Mono<MovementEntity> depositWithdrawOrTransferMoneyFromBankAccount(MovementEntity movement);

}
