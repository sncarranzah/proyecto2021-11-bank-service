package pe.com.bank.service.movement.dto.mapper;

import org.mapstruct.Mapper;

import pe.com.bank.service.movement.dto.CreditEntity;
import pe.com.bank.service.movement.dto.model.CreditModel;

@Mapper(componentModel = "spring")
public interface CreditMapper {
	CreditEntity modelToEntity(CreditModel model);
	CreditModel entityToModel(CreditEntity event);
}
