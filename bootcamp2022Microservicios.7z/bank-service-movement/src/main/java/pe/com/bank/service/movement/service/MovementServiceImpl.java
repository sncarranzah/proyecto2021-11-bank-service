package pe.com.bank.service.movement.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;
import pe.com.bank.service.movement.entity.MovementEntity;
import pe.com.bank.service.movement.repository.MovementRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class MovementServiceImpl implements  MovementService
{
	@Autowired
    private MovementRepository movementRepository;
	@Autowired
	private DebitServiceWeb debitServiceWeb;
	@Autowired
	private CreditServiceWeb creditServiceWeb;
	

    @Override
    public Mono< MovementEntity> save( MovementEntity movementEntity) {
        return movementRepository.save(movementEntity);
    }

    @Override
    public Mono< MovementEntity> findById(String id) {
        return movementRepository.findById(id);
    }

    @Override
    public Mono< MovementEntity> update( MovementEntity movementEntity) {
        return movementRepository.save(movementEntity);
    }

    @Override
    public Mono<Void> deleteById(String id) {
        return movementRepository.deleteById(id);
    }

    @Override
    public Flux<MovementEntity> findAll() {
        return movementRepository.findAll();
    }
    
    /*E.1.2 Un cliente realiza un movimiento (deposita, retira o transfiere dinero) desde su cuenta bancaria de débito*/
    @Override
    public Mono<MovementEntity> depositWithdrawOrTransferMoneyFromBankAccount(MovementEntity movement)
    {
		log.trace("depositWithdrawOrTransferMoneyFromBankAccount executed {}", movement);
		return this.searchQuantityMovemInMonth(movement.getAccountNumber())
		.flatMap(quantMov -> this.getCommission(movement.getDebitType(), quantMov))
		.flatMap(commission ->
		{
			movement.setCommision((commission));
			return this.debitServiceWeb.findByAccountNumber(movement.getAccountNumber());
		})
		.flatMap(debit ->
		{
			log.trace("the origin debit is {}", debit);
			debit.setBalance(debit.getBalance() + movement.getAmount() - movement.getCommision());
			if (debit.getBalance() >= 0)
			{
				log.trace("Punto de control 9 - Sammy");
				return this.debitServiceWeb.update(debit).flatMap(debitUpdated -> 
				{
					log.trace("Punto de control 10 - Sammy: {}", debit);
					setMovementDate(movement);
					return this.save(movement).flatMap(movement2 -> {
						if (movement.getDestinyAccountNumber()!= null)//si hay transferencia
						{							
							return this.setDestinyMovement(movement)//se configura el movimiento del destino
							.flatMap(destinityMovement -> 	
								/*return*/ this.save(destinityMovement) //se registra en la bd el movimiento del destino
								.flatMap(destinityMovementCreated -> 
									/*return*/ this.debitServiceWeb.findByAccountNumber(movement.getDestinyAccountNumber())
									.flatMap(debitDestinity ->
									{
										debitDestinity.setBalance(debitDestinity.getBalance() - movement.getAmount());
										return this.debitServiceWeb.update(debitDestinity).flatMap(debitUpdated2 -> Mono.just(movement2));
									})	
								)
							);
						}
						//si no hay transferencia
						return Mono.just(movement2);
					}); 					
				});				
			}
			else
			{
				log.info("No tiene suficiente fondos para realizar la operacion.");
				return Mono.empty();
			}
		});		
    }

    
	private void setMovementDate(MovementEntity movement) {
		LocalDateTime dateTime = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
		movement.setMovementDate(dateTime.format(formatter));
	}
  
	
    public Mono<MovementEntity> setDestinyMovement(MovementEntity movement)
    {  		
		return this.debitServiceWeb.findByAccountNumber(movement.getDestinyAccountNumber())
		.flatMap(debitClient ->
		{
			MovementEntity destinyMovement = new MovementEntity();
			this.setCommonPropertiesOfDestinyMovement( movement, destinyMovement);
			if (debitClient != null)
			{
				destinyMovement.setAccountType("DEBIT");
				destinyMovement.setDebitType(debitClient.getDebitType());
				return Mono.just(destinyMovement);
			}
			else // en caso sea credito
			{
				return this.creditServiceWeb.findByAccountNumber(movement.getDestinyAccountNumber())
				.flatMap(creditClient ->
				{
					destinyMovement.setAccountType("CREDIT");
					destinyMovement.setCreditType(creditClient.getCreditType());	
					return Mono.just(destinyMovement);
				});
				
			}
		});
		
		
    }
    
    public void setCommonPropertiesOfDestinyMovement(MovementEntity originMovement, MovementEntity destinyMovement)
    {
    	destinyMovement.setAmount(-originMovement.getAmount());
		destinyMovement.setOriginAccountNumber(originMovement.getOriginAccountNumber());
		destinyMovement.setDestinyAccountNumber(originMovement.getDestinyAccountNumber());
		destinyMovement.setAccountNumber(originMovement.getDestinyAccountNumber());
		destinyMovement.setCommision(0.0);
		destinyMovement.setConcept("TRANSFERENCIA");
		this.setMovementDate(destinyMovement);
    }
    
    public Mono<Long> searchQuantityMovemInMonth(String accountNumber)
    {
    	log.trace("searchQuantityMovemInMonth executed {}", accountNumber);
    	Calendar cal = Calendar.getInstance();
    	int actualYear = cal.get(Calendar.YEAR);
    	int actualMonth = cal.get(Calendar.MONTH);
    	int lastDayMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
    	String startdate = actualYear + "-" + actualMonth + "-" + "1" + "'T'" + "00:00:00.000'Z'";
    	String endDate = actualYear + "-" + actualMonth + "-" + lastDayMonth + "'T'" + "23:59:59.999'Z'";
    	Flux<MovementEntity> fluxMov = this.movementRepository.findByMovementDateBetweenAndAccountNumber(startdate,endDate,accountNumber);
    	log.trace("The quantity movement in month is: {}", fluxMov.count());
    	return fluxMov.count();
    }
    
    
    public Mono<Double> getCommission(String debitType,Long movemInMonth)
    {
    	log.trace("getCommission executed {} : {}", debitType,movemInMonth);
    	return this.debitServiceWeb.findAllDebitFeatures().
    	map(debitFeaturesBD -> 
    		{
    			Double commission;
    	    	if (debitType.equals("SAVINGS")  && movemInMonth > debitFeaturesBD.getMaxNumberMovemSavingsByMonth()) commission = debitFeaturesBD.getCommisAmountByMovemSaving();
    	    	else if (debitType.equals("CURRENT ACCOUNT") && movemInMonth > debitFeaturesBD.getMaxNumberMovemCurrentAccountByMonth()) commission = debitFeaturesBD.getCommisAmountByMovemCurrentAccount();
    	    	else if (debitType.equals("FIXED TERM") && movemInMonth > debitFeaturesBD.getMaxNumberMovemFixedTermByMonth()) commission = debitFeaturesBD.getCommisAmountByMovemFixedTerm();
    	    	else commission = 0.0;
    	    	return commission;
    		}
    	).elementAt(0);
    }
}
