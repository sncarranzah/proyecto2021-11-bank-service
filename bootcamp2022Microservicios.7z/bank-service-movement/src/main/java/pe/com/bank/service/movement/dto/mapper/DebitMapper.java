package pe.com.bank.service.movement.dto.mapper;

import org.mapstruct.Mapper;

import pe.com.bank.service.movement.dto.DebitEntity;
import pe.com.bank.service.movement.dto.model.DebitModel;

@Mapper(componentModel = "spring")
public interface DebitMapper {
	DebitEntity modelToEntity(DebitModel model);
	DebitModel entityToModel(DebitEntity event);
}
