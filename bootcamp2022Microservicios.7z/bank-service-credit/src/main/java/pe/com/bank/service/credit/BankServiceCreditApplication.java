package pe.com.bank.service.credit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankServiceCreditApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankServiceCreditApplication.class, args);
	}

}
